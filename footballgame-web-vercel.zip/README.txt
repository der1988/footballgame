Football Game - browser build

From this extracted folder, run: npx vercel
Sign in to your Vercel account when requested. Use this folder as the project root.
vercel.json already selects dist/ with no build or install step.

Controls: arrows move, A shoot/header, S pass/tackle, D cross/slide, Q switch player, E close control.
Click the pitch to focus the keyboard.

Tested in Chromium. Native replay/video export are disabled in this browser build.
Source: https://github.com/der1988/footballgame/tree/web-vercel
