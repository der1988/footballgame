Football Game - browser build

From this extracted folder, run: npx vercel
Sign in to your Vercel account when requested. Use this folder as the project root.
vercel.json already selects dist/ with no build or install step.

Before starting, choose 5-4-1 or 5-3-2 (defensive), 4-4-2 (balanced), 3-4-3 or 3-2-3-2 (attacking).
All formations field ten outfield players plus a keeper. The opposition uses 4-4-2.
Formation changes roles, support positions, line height, width and pressing range.

Controls: arrows move, A shoot/header, S pass/tackle, D cross/slide, Q switch player, E close control.
Click the pitch to focus the keyboard.

Tested in Chromium, including all five formations. 160 native tests passed. Native replay/video export disabled in the browser build.
Source: https://github.com/der1988/footballgame/tree/web-vercel
